Modo de uso

Para ejecutar este programa se recomienda el uso de algún IDE el cual facilite la vista de plots/graficos.

Spicy:
Al abrir Spicy y cargar el archivo main.py al editor, deberá ejecutar, apretando el boton de play verde en la parte de la barra de herramientas, y automaticamente se generarán
los audios e imagenes resultados de los archivos AudioFC1 (1).wav, AudioCR.wav, brown_noise.wav

En el informe se menciona más acerca del uso de AudioFC1 (1).wav y no de AudioFC1.wav, de cualquier manera si se quiere hacer correr el programa, con el audio original
se puede modificar la linea 33 y cambiar el nombre del archivo por exactamente : AudioFC1.wav

Por el IDE va a poder navegar a través de todos los plots (o graficos) que genera este programa por el visor en la esquina superior derecha


Consola Python IDLE:
Al ejecutar, haciendo doble click en el archivo se abrirá una consola negra, al cabo de una fracción de segundo saldrá el primer plot (o grafico) el cual la única manera de avanzar al siguiente
y que eventualmente se termine el programa es haciendo click en el botón X en la interfaz del grafico que se está mostrando.


Para ambos casos se necesitan los archivos minimos necesarios para poder hacer funcionar el programa AudioFC1 (1).wav, AudioCR.wav, brown_noise.wav, opcional: AudioFC.wav
en la carpeta en la cual se ejecutará el programa. NO MOVER NADA.